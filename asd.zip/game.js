let jatekos = new Player()

let weak_enemy = new Enemy(-1)
//fight(jatekos, weak_enemy)