function fight(player, enemy) {
    playerturn = true
    while (true) {
        if (playerturn) {
            console.log(`${player} köre, meglendíti a kardját, majd lesújt`)
            if (damage = turn(player, enemy)) {
                console.log(`${player} csúnyán állbavágta ellenfelét, ${damage} sebzést okozva`)
                if (enemy.hp < 0) {
                    return player
                }
                console.log(`${enemy.hp} élete maradt`)
                continue
            }
            console.log(`${enemy} kivédte a támadást!`)
        }
        console.log(`${enemy} rohamot indít`)
        if (damage = turn(player, enemy)) {
            console.log(`${enemy} támadása súlyos sebeket okozott, a kalandor ${damage} sebzést kapott`)
            if (player.hp < 0) {
                return enemy
            }
            console.log(`${player.hp} élettel túlélte`)
            continue
        }
        console.log(`A hős ${player} sikeresen hártott!`)
    }
}

function turn(attacker, defender) {
    if (Math.random * 100 <= defender.def) {
        return false
    }
    damage = attacker.dmg * attacker.crit
    defended = damage * defender.def
    defender.hp -= defended
    return defended
}