/* class Item {
    constructor(name, lore, strength, dexterity, intelligence, endurance){
        this.name = name
        this.lore = lore
        this.strength = strength
        this.dexterity = dexterity
        this.intelligence = intelligence
        this.endurance = endurance
    }
} */

class Entity {
    constructor(lvl, hp, dmg, dodge, crit, def, inv) {
        this.lvl = lvl
        this.hp = hp
        this.max_hp = hp
        this.inv = inv
        this.dmg = dmg
        this.dodge = dodge
        this.crit = crit
        this.def = def
        this.inv = inv
    }
}

class Player extends Entity {
    constructor(lvl = 1, strength = 1, dexterity = 1, intelligence = 1, endurance = 1) {
        super()
        this.dmg = this.get_dmg(lvl, strength)
        this.dodge = this.get_dodge(dexterity)
        this.crit = this.get_crit(intelligence)
        this.def = this.get_def(endurance)
        this.available = 4
        this.balance = 10
        this.updateGold()
    }
    addPoint(stat) {
        this[stat]++
        this.available--
        stats_view()
    }
    updateGold() {
        document.getElementById("gold").innerHTML = this.balance
    }
    get_dmg(lvl, strength) {
        return (5 + (lvl * 2) + (strength / 2)).toFixed(2)
    }
    get_dodge(dexterity) {
        return (-(50 / (1.025 ** dexterity)) + 50).toFixed(2)
    }
    get_crit(intelligence) {
        return (-(90 / (1.02 ** intelligence)) + 90).toFixed(2)
    }
    get_def(endurance) {
        return (-(50 / (1.02 ** endurance)) + 50).toFixed(2)
    }
}


class Enemy extends Entity {

    constructor(hardness = 0) {
        super()
        this.name = this.#genName()
        this.lvl = this.#getHardness()
        this.dmg = this.#getDmg()
        this.dodge = this.#getDodge()
        this.crit = this.#getCrit()
        this.def = this.#getDef()
    }#genName() {
        return jelzo[Math.floor(Math.random() * jelzo.length)] + nev[Math.floor(Math.random() * nev.length)]
    }#getHardness(hardness) {
        let intervall = (jatekos.lvl / 10) * 2
        let min = (jatekos.lvl - intervall / 2) + (hardness * intervall)
        let max = (jatekos.lvl + intervall / 2) + (hardness * intervall)
        return Math.random() * (max - min) + max
    }#getDmg() {
        return (5 + (this.lvl * 2) + (Math.random() * (this.lvl / 2) + this.lvl)).toFixed(2)
    }#getDodge() {
        return Math.random() * (this.lvl / 10) + this.lvl / 100
    }#getCrit() {
        return Math.random() * (this.lvl / 20) + this.lvl / 200
    }#getDef() {
        console.log(Math.random() * (this.lvl / 20) + this.lvl / 200)
        return Math.random() * (this.lvl / 20) + this.lvl / 200
    }
}